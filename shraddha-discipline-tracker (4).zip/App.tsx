
import React, { useState, useCallback } from 'react';
import { DisciplineRecord, InfractionType } from './types';
import Header from './components/Header';
import DisciplineForm from './components/DisciplineForm';
import RecordList from './components/RecordList';

const App: React.FC = () => {
  const [records, setRecords] = useState<DisciplineRecord[]>([
    {
      id: '1',
      studentName: 'Rohan Sharma',
      grade: '10 A',
      date: '2023-10-26',
      infractionType: InfractionType.HAIR_CUT,
      notes: 'Hair not cut according to school regulations. A verbal warning was given.',
    },
    {
      id: '2',
      studentName: 'Priya Patel',
      grade: '8 B',
      date: '2023-10-26',
      infractionType: InfractionType.LATE_COMER,
      notes: 'Arrived 15 minutes late to the morning assembly.',
    },
     {
      id: '3',
      studentName: 'Amit Singh',
      grade: '12 C',
      date: '2023-10-25',
      infractionType: InfractionType.UNIFORM,
      notes: 'Was not wearing the proper school tie.',
    },
  ]);

  const handleAddRecord = useCallback((newRecord: Omit<DisciplineRecord, 'id' | 'date'>) => {
    setRecords(prevRecords => [
      {
        ...newRecord,
        id: new Date().toISOString() + Math.random(),
        date: new Date().toISOString().split('T')[0],
      },
      ...prevRecords,
    ]);
  }, []);

  return (
    <div className="min-h-screen bg-slate-100 font-sans">
      <Header />
      <main className="container mx-auto p-4 md:p-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1">
            <DisciplineForm onAddRecord={handleAddRecord} />
          </div>
          <div className="lg:col-span-2">
            <RecordList records={records} />
          </div>
        </div>
      </main>
    </div>
  );
};

export default App;
