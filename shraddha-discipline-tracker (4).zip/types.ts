
export enum InfractionType {
  HAIR_CUT = 'Hair Cut',
  UNIFORM = 'Uniform',
  LATE_COMER = 'Late Comer',
  ID_CARD = 'ID Card',
  OTHER = 'Other',
}

export interface DisciplineRecord {
  id: string;
  studentName: string;
  grade: string;
  date: string;
  infractionType: InfractionType;
  notes: string;
}
