import React, { useState } from 'react';
import { DisciplineRecord } from '../types';
import RecordCard from './RecordCard';
import * as XLSX from 'xlsx';
import ReportModal from './ReportModal';

interface RecordListProps {
  records: DisciplineRecord[];
}

const RecordList: React.FC<RecordListProps> = ({ records }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [weeklyRecords, setWeeklyRecords] = useState<DisciplineRecord[]>([]);

  const handleExportToExcel = () => {
    if (weeklyRecords.length === 0) {
      alert("No records to export.");
      return;
    }

    const worksheet = XLSX.utils.json_to_sheet(weeklyRecords);
    const workbook = XLSX.book_new();
    XLSX.book_append_sheet(workbook, worksheet, "Weekly Discipline Report");
    
    const today = new Date().toISOString().split('T')[0];
    XLSX.writeFile(workbook, `Shraddha_Discipline_Report_Weekly_${today}.xlsx`);
  };

  const handleViewReport = () => {
    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);

    const filteredRecords = records.filter(record => {
      const recordDate = new Date(record.date);
      return recordDate >= oneWeekAgo;
    });

    if (filteredRecords.length === 0) {
      alert("No records found in the last 7 days to show.");
      return;
    }
    
    setWeeklyRecords(filteredRecords);
    setIsModalOpen(true);
  };

  return (
    <>
      {isModalOpen && (
        <ReportModal 
          records={weeklyRecords}
          onClose={() => setIsModalOpen(false)}
          onExport={handleExportToExcel}
        />
      )}
      <div className="bg-white p-6 rounded-lg shadow-lg">
          <div className="flex flex-col sm:flex-row justify-between sm:items-center mb-6">
              <h2 className="text-xl font-bold text-slate-700 mb-4 sm:mb-0">Discipline Records</h2>
              <button
                onClick={handleViewReport}
                className="inline-flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-teal-600 hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 transition-colors"
                aria-label="View weekly discipline report"
              >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                    <path strokeLinecap="round" strokeLinejoin="round" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                  </svg>
                  View Weekly Report
              </button>
          </div>
          {records.length === 0 ? (
              <div className="text-center py-10 text-slate-500">
                  <p>No records found. Add a new record to get started.</p>
              </div>
          ) : (
              <div className="space-y-4">
                  {records.map((record) => (
                      <RecordCard key={record.id} record={record} />
                  ))}
              </div>
          )}
      </div>
    </>
  );
};

export default RecordList;