import React, { useState } from 'react';
import { DisciplineRecord, InfractionType } from '../types';
import QRScanner from './QRScanner';

interface DisciplineFormProps {
  onAddRecord: (record: Omit<DisciplineRecord, 'id' | 'date'>) => void;
}

const DisciplineForm: React.FC<DisciplineFormProps> = ({ onAddRecord }) => {
  const [studentName, setStudentName] = useState('');
  const [selectedClass, setSelectedClass] = useState('1');
  const [selectedSection, setSelectedSection] = useState('A');
  const [infractionType, setInfractionType] = useState<InfractionType>(InfractionType.UNIFORM);
  const [notes, setNotes] = useState('');
  const [isScannerOpen, setIsScannerOpen] = useState(false);

  const classes = Array.from({ length: 12 }, (_, i) => (i + 1).toString());
  const sections_1_to_10 = ['A', 'B', 'C', 'D'];
  const sections_11_to_12 = ['A1', 'A2', 'B', 'C'];
  
  const getAvailableSections = (className: string) => {
    return parseInt(className, 10) >= 11 ? sections_11_to_12 : sections_1_to_10;
  };

  const handleClassChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newClass = e.target.value;
    setSelectedClass(newClass);
    setSelectedSection(getAvailableSections(newClass)[0]);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!studentName.trim()) {
      alert('Please enter or scan student name.');
      return;
    }
    const grade = `${selectedClass} ${selectedSection}`;
    onAddRecord({ studentName, grade, infractionType, notes });
    setStudentName('');
    setSelectedClass('1');
    setSelectedSection('A');
    setInfractionType(InfractionType.UNIFORM);
    setNotes('');
  };
  
  const handleScanSuccess = (decodedText: string) => {
    setStudentName(decodedText);
    setIsScannerOpen(false);
  };
  
  const availableSections = getAvailableSections(selectedClass);

  return (
    <>
      {isScannerOpen && (
          <QRScanner 
              onScanSuccess={handleScanSuccess} 
              onClose={() => setIsScannerOpen(false)} 
          />
      )}
      <div className="bg-white p-6 rounded-lg shadow-lg h-full">
        <h2 className="text-xl font-bold text-slate-700 mb-6">Add New Record</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <div className="flex justify-between items-center mb-1">
              <label htmlFor="studentName" className="block text-sm font-medium text-slate-600">
                Student Name
              </label>
              <button 
                type="button" 
                onClick={() => setIsScannerOpen(true)}
                className="inline-flex items-center text-sm font-medium text-indigo-600 hover:text-indigo-800"
                aria-label="Scan student QR code"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v1m6 11h2m-6.5 6.5v-1m-6.5-5.5H4M4 12l1.5-1.5M4 4l1.5 1.5M12 20v-1m6-11h-2M17.5 4.5l-1.5 1.5M20 20l-1.5-1.5" />
                </svg>
                Scan QR
              </button>
            </div>
            <input
              id="studentName"
              type="text"
              value={studentName}
              onChange={(e) => setStudentName(e.target.value)}
              className="block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              placeholder="e.g., Anjali Mehta"
              required
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
              <div>
                <label htmlFor="class" className="block text-sm font-medium text-slate-600">
                  Class
                </label>
                <select
                  id="class"
                  value={selectedClass}
                  onChange={handleClassChange}
                  className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-slate-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                >
                  {classes.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label htmlFor="section" className="block text-sm font-medium text-slate-600">
                  Section
                </label>
                <select
                  id="section"
                  value={selectedSection}
                  onChange={(e) => setSelectedSection(e.target.value)}
                  className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-slate-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                >
                  {availableSections.map((section) => (
                    <option key={section} value={section}>
                      {section}
                    </option>
                  ))}
                </select>
              </div>
          </div>
          
          <div>
            <label htmlFor="infractionType" className="block text-sm font-medium text-slate-600">
              Infraction Type
            </label>
            <select
              id="infractionType"
              value={infractionType}
              onChange={(e) => setInfractionType(e.target.value as InfractionType)}
              className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-slate-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
            >
              {Object.values(InfractionType).map((type) => (
                <option key={type} value={type}>
                  {type}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="notes" className="block text-sm font-medium text-slate-600">
              Notes
            </label>
            <textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={4}
              className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              placeholder="Add any relevant details..."
            />
          </div>
          <button
            type="submit"
            className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors"
          >
            Add Record
          </button>
        </form>
      </div>
    </>
  );
};

export default DisciplineForm;